# tablegen README

This VSCode colorizer extension is a translation of the textmate bunble to
VSCode using the "yo code" npm package. Currently, keywords, comments, and
strings are highlighted.

To install this VSCode .td file colorizer, copy it to the following locations
per your Operating System:

  - Windows: %USERPROFILE%\.vscode\extensions
  - Mac: ~/.vscode/extensions
  - Linux: ~/.vscode/extensions

