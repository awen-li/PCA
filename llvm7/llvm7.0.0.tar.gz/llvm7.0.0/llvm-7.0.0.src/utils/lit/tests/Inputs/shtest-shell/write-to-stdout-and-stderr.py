#!/usr/bin/env python

import sys


sys.stdout.write("a line on stdout\n")
sys.stdout.flush()

sys.stderr.write("a line on stderr\n")
sys.stderr.flush()
